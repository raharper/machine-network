/* SPDX-License-Identifier: AGPL-3.0-or-later
 * Copyright (c) 2022 Red Hat GmbH
 * Author: Stefano Brivio <sbrivio@redhat.com>
 */

#ifndef ARCH_H
#define ARCH_H

void arch_avx2_exec(char **argv);

#endif /* ARCH_H */
